package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.LoginLogout;
import com.example.demo.model.User;
import com.example.demo.repository.LoginLogoutRepository;
import com.example.demo.repository.UserRepository;

@Controller
//@SessionAttributes("loginlogout")
public class loginController {
	
	@Autowired
	LoginLogoutRepository repos;
	
	@Autowired
	UserRepository urepos;
	
	@Autowired
	LoginLogout loginlogout;
	
	@RequestMapping("/admin")
	public ModelAndView admin() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("login");
		mv.addObject("loginlogout",loginlogout);
		return mv;
	}
	
	@RequestMapping("/user")
	public ModelAndView user() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("loginRegisterForUser");
		return mv;
	}
	
	@RequestMapping("/home")
	public ModelAndView home(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("home");
		return mv;
	}
	
	@RequestMapping("/login")
	public ModelAndView login(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("login");
		mv.addObject("loginlogout",loginlogout);
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView Logout(HttpSession ss)
	{
		ModelAndView mv=new ModelAndView();
		ss.invalidate();
		mv.setViewName("home");
		mv.addObject("message","Logout Successfully!");
		return mv;
	}
	
	@RequestMapping("/checkSession")
	public ModelAndView Nsecure(HttpSession ss)
	{
		ModelAndView mv=new ModelAndView();
		if(ss.getAttribute("pom")!=null && loginlogout.getRole().equals("User"))
		{
		    mv.setViewName("user");
		}else if(ss.getAttribute("pom")!=null && loginlogout.getRole().equals("Admin")) {
			mv.setViewName("admin");
		}else {
			mv.setViewName("login");
			mv.addObject("loginlogout",loginlogout);
		}
		return mv;
	}
	
	@RequestMapping("/loginProcess")
		public @ResponseBody ModelAndView loginProcess(HttpServletRequest req,HttpSession session) {
		ModelAndView mv=new ModelAndView();
		
		loginlogout=repos.findByUsername(req.getParameter("username"));
		//System.out.println(loginlogout);
		if(loginlogout!=null && loginlogout.getPassword().equals(req.getParameter("password")) && loginlogout.getRole().equals("User")) {
			mv.setViewName("user");
			mv.addObject("username",loginlogout.getUsername());
			session.setAttribute("pom",loginlogout.getUsername());
		}else if(loginlogout!=null && loginlogout.getPassword().equals(req.getParameter("password"))&& loginlogout.getRole().equals("Admin")) {
			mv.setViewName("admin");
			mv.addObject("username",loginlogout.getUsername());
			session.setAttribute("pom",loginlogout.getUsername());
		}else {
			mv.setViewName("login");
			mv.addObject("loginlogout",loginlogout);
			mv.addObject("message", "Username or Password is wrong!!");
		}
		//mv.addObject("loginlogout",loginlogout);
		
		return mv;
	}
	
	
	
	@RequestMapping("/register")
	public ModelAndView register() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userRegister");
		mv.addObject("user",new User());
		return mv;
	}
	
	@RequestMapping("registerProcess")
	public ModelAndView addUser(@Valid @ModelAttribute("user") User user,BindingResult bindingResult) {
		ModelAndView mv = new ModelAndView();
	    User userExists = urepos.findByemail(user.getEmail());
	    if (userExists != null) {
	        bindingResult
	                .rejectValue("email", "error.user",
	                        "There is already a user registered with the username provided");
	    }
	    if (bindingResult.hasErrors()) {
	        mv.setViewName("userRegister");
	        mv.addObject("usermessage","Something went wrong! You are not able to register");
	        mv.addObject("user",new User());
	        System.out.println(bindingResult);
	    } else {
	        urepos.save(user);
	        mv.addObject("message", "User has been registered successfully");
	        mv.addObject("loginlogout", loginlogout);
	        mv.setViewName("login");
	        
	    }
	    return mv;
	}
	

}
